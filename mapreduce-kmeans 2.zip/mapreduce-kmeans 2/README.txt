
- Acknowledgement:
    The sample code is based on Thomas's implementation of K-means on hadoop.
    It is modified as one learning material for RMIT's big data processing course.
    The original implementation can be found there: https://github.com/thomasjungblut/mapreduce-kmeans
