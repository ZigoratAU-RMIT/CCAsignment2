package com.example.uberrequest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class webBrowserAnalytics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_browser_analytics);
    }
}