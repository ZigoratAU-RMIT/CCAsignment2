
Student Name: Sepideh Berangi (S3793021)
Student Name: Mohammad Farshidmehr (S3308107)
 


With this mobile app/website, the clients will be able to access their current location information or any specific part of the map, and it will show the demand rate of UBER requests. This information could be useful for UBER to identify the time and location of busy areas, for profiting more in their business. In addition, this data will be useful for the local government's traffic governance and the police to check the traffic flow of these areas in order to improve their services.

https://github.com/ZigoratRmit/CCAsignment2
